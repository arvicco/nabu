#!/usr/bin/env python3
"""Render a supplied witness PDF and verify its recipe-derived media."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import tempfile
import time
from collections import Counter
from collections import defaultdict
from pathlib import Path

from PIL import Image


RELEASE = Path(__file__).resolve().parents[1]
DATASET = RELEASE / "dataset"
RELEASE_MEDIA = RELEASE / "witness-images"
BUILD = RELEASE / "build"


def duration(seconds: float) -> str:
    """Format a short, human-readable elapsed or remaining duration."""
    seconds = round(seconds)
    if seconds < 60:
        return f"{seconds}s"
    return f"{seconds // 60}m {seconds % 60:02}s"


def progress(stage: str, completed: int, total: int, started: float) -> None:
    """Report measured elapsed time and a linear ETA for one build stage."""
    elapsed = time.monotonic() - started
    remaining = elapsed * (total - completed) / completed if completed else 0
    print(
        f"{stage}: {completed}/{total} "
        f"(elapsed {duration(elapsed)}, ETA {duration(remaining)})."
    )


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_strip_filename(label: str) -> str:
    """Return the reviewed strip filename corresponding to a source label."""
    return label.replace("/", "-") + ".png"


def strip_label(value: object) -> str:
    label = str(value)
    return f"{int(label):02}" if label.isdigit() else label


def strip_filename(witness: str, crop: dict) -> str:
    if "segment" in crop:
        return f"strip{strip_label(crop['strip'])}.{crop['segment']}.png"
    return safe_strip_filename(crop["strip"])


def character_source_filename(witness: str, crop: dict) -> str:
    location = crop["source_location"]
    if "segment" in crop:
        return f"strip{strip_label(location['strip'])}.{crop['segment']}.png"
    return safe_strip_filename(location["strip"])


def character_filename(witness: str, crop: dict) -> str:
    location = crop["source_location"]
    if "segment" in crop:
        return (
            f"strip{strip_label(location['strip'])}."
            f"{crop['segment']}.{crop['segment_item']}.png"
        )
    return f"strip{location['strip']}.{location['item']}.png"


def render_pages(pdf: Path, pages: set[int], dpi: int, directory: Path) -> dict[int, Path]:
    info = subprocess.check_output(["pdfinfo", str(pdf)], text=True)
    page_count_match = re.search(r"^Pages:\s+(\d+)$", info, re.MULTILINE)
    if page_count_match is None:
        raise RuntimeError(f"pdfinfo did not report a page count for {pdf}.")
    page_count = int(page_count_match.group(1))
    if max(pages) > page_count:
        raise ValueError(
            f"Recipe requires PDF page {max(pages)}, but {pdf} has only {page_count} pages."
        )
    directory.mkdir(parents=True, exist_ok=True)
    rendered = {}
    started = time.monotonic()
    for index, page in enumerate(sorted(pages), start=1):
        prefix = directory / "page"
        before = set(directory.glob("page-*.png"))
        subprocess.run(
            [
                "pdftoppm",
                "-f",
                str(page),
                "-l",
                str(page),
                "-r",
                str(dpi),
                "-png",
                str(pdf),
                str(prefix),
            ],
            check=True,
        )
        created = set(directory.glob("page-*.png")) - before
        if len(created) != 1:
            raise RuntimeError(f"pdftoppm did not render PDF page {page}.")
        rendered[page] = created.pop()
        progress(f"Rendering PDF page {page}", index, len(pages), started)
    return rendered


def validate_crop(crop: dict, width: int, height: int, name: str) -> tuple[int, int, int, int]:
    box = tuple(crop["crop_box"])
    left, top, right, bottom = box
    if not (0 <= left < right <= width and 0 <= top < bottom <= height):
        raise ValueError(f"{name} crop box {box} is outside {width}x{height}.")
    return box


def write_crop(image: Image.Image, crop: dict, target: Path, name: str) -> None:
    box = validate_crop(crop, image.width, image.height, name)
    target.parent.mkdir(parents=True, exist_ok=True)
    image.crop(box).save(target)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def pixel_sha256(path: Path) -> tuple[str, str, int, int]:
    """Hash decoded pixels and image identity, independent of PNG encoding."""
    with Image.open(path) as image:
        image.load()
        digest = hashlib.sha256()
        digest.update(
            f"{image.mode}\0{image.width}\0{image.height}\0".encode("ascii")
        )
        digest.update(image.tobytes())
        return digest.hexdigest(), image.mode, image.width, image.height


def generated_files(output: Path) -> list[Path]:
    return sorted(
        path
        for directory in (output / "strips", output / "characters")
        for path in directory.rglob("*.png")
    )


def expected_manifest_path(witness: str) -> Path:
    return DATASET / witness / "expected_media.json"


def strip_cache_path(work: Path) -> Path:
    return work / "strip_recipes.json"


def strip_recipe_signature(crop: dict) -> str:
    return json.dumps(crop, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def read_strip_cache(work: Path) -> dict:
    path = strip_cache_path(work)
    if not path.is_file():
        return {}
    try:
        return read_json(path)
    except json.JSONDecodeError:
        return {}


def write_strip_cache(
    witness: str, work: Path, pdf_digest: str, strips: dict
) -> None:
    work.mkdir(parents=True, exist_ok=True)
    strip_cache_path(work).write_text(
        json.dumps(
            {
                "source_pdf_sha256": pdf_digest,
                "render_dpi": strips["render_dpi"],
                "recipes": {
                    strip_filename(witness, crop): strip_recipe_signature(crop)
                    for crop in strips["crops"]
                },
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def cached_strip_filenames(
    witness: str,
    output: Path,
    work: Path,
    pdf_digest: str,
    strips: dict,
    no_cache: bool,
) -> set[str]:
    if no_cache:
        return set()
    cache = read_strip_cache(work)
    if (
        cache.get("source_pdf_sha256") != pdf_digest
        or cache.get("render_dpi") != strips["render_dpi"]
        or not isinstance(cache.get("recipes"), dict)
    ):
        expected_path = expected_manifest_path(witness)
        if not expected_path.is_file():
            return set()
        expected = read_json(expected_path)
        expected_strips = {
            entry["path"].removeprefix("strips/"): entry["sha256"]
            for entry in expected["files"]
            if entry["path"].startswith("strips/")
        }
        filenames = {strip_filename(witness, crop) for crop in strips["crops"]}
        if (
            expected.get("source_pdf_sha256") != pdf_digest
            or expected.get("render_dpi") != strips["render_dpi"]
            or set(expected_strips) != filenames
            or any(
                not (path := output / "strips" / filename).is_file()
                or sha256(path) != expected_strips[filename]
                for filename in filenames
            )
        ):
            return set()
        return filenames
    return {
        filename
        for crop in strips["crops"]
        if (
            (filename := strip_filename(witness, crop)) in cache["recipes"]
            and cache["recipes"][filename] == strip_recipe_signature(crop)
            and (output / "strips" / filename).is_file()
        )
    }


def expected_manifest(witness: str, pdf: Path, output: Path) -> dict:
    files = []
    for path in generated_files(output):
        pixel_digest, mode, width, height = pixel_sha256(path)
        files.append(
            {
                "path": path.relative_to(output).as_posix(),
                "sha256": sha256(path),
                "pixel_sha256": pixel_digest,
                "mode": mode,
                "width": width,
                "height": height,
            }
        )
    return {
        "schema_version": "1.1",
        "witness": witness,
        "source_pdf_sha256": sha256(pdf),
        "render_dpi": read_json(DATASET / witness / "strip_mapping.json")["render_dpi"],
        "files": files,
    }


def write_expected_manifest(witness: str, pdf: Path, output: Path) -> Path:
    """Record checksums from a reviewed rebuild for subsequent verification."""
    path = expected_manifest_path(witness)
    path.write_text(
        json.dumps(expected_manifest(witness, pdf, output), ensure_ascii=False, indent=2)
        + "\n",
        encoding="utf-8",
    )
    return path


def compare_expected(output: Path, expected: dict) -> tuple[Counter, list[dict]]:
    """Compare every output against the checked-in exact and decoded-pixel hashes."""
    actual = {path.relative_to(output).as_posix(): path for path in generated_files(output)}
    expected_files = {entry["path"]: entry for entry in expected["files"]}
    if len(expected_files) != len(expected["files"]):
        raise ValueError("Expected media manifest contains duplicate paths.")

    counts: Counter = Counter()
    comparisons = []
    for name in sorted(set(actual) | set(expected_files)):
        entry = expected_files.get(name)
        file_path = actual.get(name)
        if entry is None:
            status = "unexpected"
        elif file_path is None:
            status = "missing"
        elif sha256(file_path) == entry["sha256"]:
            status = "exact"
        else:
            pixel_digest, mode, width, height = pixel_sha256(file_path)
            status = (
                "pixel-match"
                if (
                    pixel_digest == entry["pixel_sha256"]
                    and mode == entry["mode"]
                    and width == entry["width"]
                    and height == entry["height"]
                )
                else "different"
            )
        counts[status] += 1
        comparisons.append({"file": name, "status": status})
    return counts, comparisons


def validate_output_directory(witness: str, output: Path) -> Path:
    resolved = output.resolve()
    canonical = (RELEASE_MEDIA / witness).resolve()
    if RELEASE.resolve().is_relative_to(resolved):
        raise ValueError("Output may not be the release root or one of its parents.")
    if resolved.is_relative_to(RELEASE.resolve()) and resolved != canonical:
        raise ValueError(
            f"Release-local output must be the canonical {canonical.relative_to(RELEASE)}."
        )
    if (
        not resolved.is_relative_to(RELEASE.resolve())
        and resolved.is_dir()
        and any(resolved.iterdir())
    ):
        raise ValueError("External output directory must be absent or empty.")
    return resolved


def validate_work_directory(work: Path) -> Path:
    resolved = work.resolve()
    if not resolved.is_relative_to(BUILD.resolve()) or resolved == BUILD.resolve():
        raise ValueError("Work directory must be a witness-specific directory below build/.")
    return resolved


def build(
    witness: str,
    pdf: Path,
    output: Path,
    work: Path | None = None,
    write_expected: bool = False,
    no_cache: bool = False,
) -> tuple[Counter, dict[str, list[dict]]]:
    if not pdf.is_file():
        raise FileNotFoundError(pdf)
    output = validate_output_directory(witness, output)
    work = validate_work_directory(work or BUILD / witness)
    expected_path = expected_manifest_path(witness)
    if not write_expected and not expected_path.is_file():
        raise FileNotFoundError(
            f"Missing expected-media manifest for {witness}: {expected_path}"
        )
    pdf_digest = sha256(pdf)
    if not write_expected:
        expected_source = read_json(expected_path)["source_pdf_sha256"]
        if expected_source != pdf_digest:
            raise ValueError(
                f"Source PDF checksum does not match {expected_path}."
            )

    dataset_directory = DATASET / witness
    strips = read_json(dataset_directory / "strip_mapping.json")
    characters = read_json(dataset_directory / "character_mapping.json")
    if strips["render_dpi"] < 1:
        raise ValueError("Recipe render_dpi must be positive.")
    noncanonical = [
        (crop["file"], character_filename(witness, crop))
        for crop in characters["mappings"]
        if crop["file"] != character_filename(witness, crop)
    ]
    if noncanonical:
        actual, expected = noncanonical[0]
        raise ValueError(
            f"Noncanonical {witness} character filename: {actual}; expected {expected}"
        )

    output.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    counts: Counter = Counter()
    generated_strips = output / "strips"
    generated_characters = output / "characters"
    comparisons: dict[str, list[dict]] = {"expected_media": []}
    cached = cached_strip_filenames(
        witness,
        output,
        work,
        pdf_digest,
        strips,
        no_cache,
    )
    missing = [
        crop for crop in strips["crops"] if strip_filename(witness, crop) not in cached
    ]
    counts["strips_reused"] = len(cached)
    if missing:
        pages = {crop["pdf_page"] for crop in missing}
        with tempfile.TemporaryDirectory(dir=work) as temporary:
            rendered = render_pages(
                pdf, pages, strips["render_dpi"], Path(temporary) / "rendered-pages"
            )
            strip_started = time.monotonic()
            for index, crop in enumerate(missing, start=1):
                filename = strip_filename(witness, crop)
                target = generated_strips / filename
                with Image.open(rendered[crop["pdf_page"]]) as page:
                    write_crop(page, crop, target, f"strip {filename}")
                counts["strips"] += 1
                if index == len(missing) or index % 25 == 0:
                    progress("Cropping strips", index, len(missing), strip_started)
    current_strips = {strip_filename(witness, crop) for crop in strips["crops"]}
    for path in generated_strips.glob("*.png"):
        if path.name not in current_strips:
            path.unlink()
    write_strip_cache(witness, work, pdf_digest, strips)

    characters_by_strip: dict[str, list[dict]] = defaultdict(list)
    for crop in characters["mappings"]:
        characters_by_strip[character_source_filename(witness, crop)].append(crop)
    completed_characters = 0
    total_characters = len(characters["mappings"])
    character_started = time.monotonic()
    current_characters = {
        mapping["file"] for mapping in characters["mappings"]
    }
    for filename, crops in characters_by_strip.items():
        source = generated_strips / filename
        if not source.is_file():
            raise ValueError(f"Character crop refers to missing strip: {crops[0]['file']}")
        with Image.open(source) as strip:
            for crop in crops:
                target = generated_characters / crop["file"]
                write_crop(strip, crop, target, f"character {crop['file']}")
                counts["characters"] += 1
                completed_characters += 1
        if completed_characters == total_characters or completed_characters % 100 < len(crops):
            progress(
                "Cropping characters",
                completed_characters,
                total_characters,
                character_started,
            )
    for path in generated_characters.rglob("*.png"):
        if path.relative_to(generated_characters).as_posix() not in current_characters:
            path.unlink()
    for directory in sorted(
        (path for path in generated_characters.rglob("*") if path.is_dir()),
        reverse=True,
    ):
        if not any(directory.iterdir()):
            directory.rmdir()

    checksum_file = work / "checksums.sha256"
    files = generated_files(output)
    checksum_file.write_text(
        "".join(
            f"{sha256(path)}  {path.relative_to(output).as_posix()}\n" for path in files
        ),
        encoding="utf-8",
    )
    counts["files"] = len(files)
    expected_comparisons: list[dict] = []
    if write_expected:
        expected_path = write_expected_manifest(witness, pdf, output)
        counts["expected_manifest_written"] = 1
    expected = read_json(expected_path)
    if expected["witness"] != witness:
        raise ValueError(f"Expected media manifest has wrong witness: {expected_path}")
    if expected["render_dpi"] != strips["render_dpi"]:
        raise ValueError(f"Expected media manifest has wrong render DPI: {expected_path}")
    source_status = (
        "match"
        if expected["source_pdf_sha256"] == pdf_digest
        else "different"
    )
    expected_counts, expected_comparisons = compare_expected(output, expected)
    comparisons["expected_media"] = expected_comparisons
    counts.update(
        {f"expected:{status}": count for status, count in expected_counts.items()}
    )
    counts[f"expected_source:{source_status}"] = 1
    (work / "verification.json").write_text(
        json.dumps(
            {
                "witness": witness,
                "source_pdf": pdf.name,
                "source_pdf_sha256": pdf_digest,
                "render_dpi": strips["render_dpi"],
                "counts": dict(sorted(counts.items())),
                "comparisons": comparisons,
                "expected_media_manifest": (
                    expected_path.relative_to(RELEASE).as_posix()
                    if expected_path.is_relative_to(RELEASE)
                    else str(expected_path)
                ),
                "expected_source_pdf_status": source_status,
                "expected_comparisons": expected_comparisons,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return counts, comparisons


def main() -> None:
    global RELEASE, DATASET, RELEASE_MEDIA, BUILD

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--witness", required=True)
    parser.add_argument(
        "--release-root",
        type=Path,
        default=RELEASE,
        help="Release directory containing dataset/ and witness-images/.",
    )
    parser.add_argument("--pdf", type=Path, required=True, help="Lawfully obtained source PDF.")
    parser.add_argument(
        "--output",
        type=Path,
        help=(
            "Final media directory; defaults to "
            "witness-images/<witness>."
        ),
    )
    parser.add_argument(
        "--work-directory",
        type=Path,
        help="Disposable work directory; defaults to build/<witness>.",
    )
    parser.add_argument(
        "--write-expected-manifest",
        action="store_true",
        help=(
            "Replace dataset/<witness>/expected_media.json with "
            "checksums from this rebuild."
        ),
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Rebuild every strip from the source PDF instead of reusing matching cached strips.",
    )
    args = parser.parse_args()
    RELEASE = args.release_root.resolve()
    DATASET = RELEASE / "dataset"
    RELEASE_MEDIA = RELEASE / "witness-images"
    BUILD = RELEASE / "build"
    output = args.output or RELEASE_MEDIA / args.witness
    work = args.work_directory or BUILD / args.witness
    counts, comparisons = build(
        args.witness,
        args.pdf,
        output,
        work=work,
        write_expected=args.write_expected_manifest,
        no_cache=args.no_cache,
    )
    print(f"Generated {counts['files']} files in {output}.")
    print(f"strips: generated={counts['strips']}, reused={counts['strips_reused']}")
    print(f"characters: generated={counts['characters']}")
    print(
        "expected media: "
        + ", ".join(
            f"{state}={counts[f'expected:{state}']}"
            for state in ("exact", "pixel-match", "different", "missing", "unexpected")
        )
        + f"; source={counts['expected_source:match']} match, "
        + f"{counts['expected_source:different']} different"
    )
    expected_failures = sum(
        counts[f"expected:{status}"] for status in ("different", "missing", "unexpected")
    )
    if (
        counts["expected_source:different"]
        or expected_failures
    ):
        if expected_failures or counts["expected_source:different"]:
            print(
                "Expected media verification failed: "
                + ", ".join(
                    entry["file"]
                    for entry in comparisons["expected_media"]
                    if entry["status"] in {"different", "missing", "unexpected"}
                )
            )
        raise SystemExit("Generated media did not pass verification.")


if __name__ == "__main__":
    main()
