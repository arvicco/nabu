# Quick Start

## Windows

Double-click `START-WINDOWS.bat`.

## macOS

Double-click `START-MAC.command`. If macOS blocks it, run:

```bash
bash START-MAC.command
```

## Manual start

From the extracted package directory:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

Open <http://localhost:8000/>.

Do not open the HTML files directly with `file://`; the viewer needs HTTP
access to its JSON files.
